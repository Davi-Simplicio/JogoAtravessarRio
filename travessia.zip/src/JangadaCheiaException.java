public class JangadaCheiaException extends Exception{
    public JangadaCheiaException() {
        super("A jangada extá cheia");
    }
}

public class FilhosSozinhosComAMaeSemOPaiException extends RuntimeException{
    public FilhosSozinhosComAMaeSemOPaiException() {
        super("Os filhos não podem ficar soinhos com a amãe na ausência do pai");
    }
}

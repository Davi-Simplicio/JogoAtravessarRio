public class Prisioneira extends Personagem{
}

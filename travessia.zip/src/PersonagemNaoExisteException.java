public class PersonagemNaoExisteException extends Exception{
    public PersonagemNaoExisteException() {
        super("O personagem não existe");
    }
}

public interface ITravessia {
}

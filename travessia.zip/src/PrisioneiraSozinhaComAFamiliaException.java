public class PrisioneiraSozinhaComAFamiliaException extends RuntimeException{
    public PrisioneiraSozinhaComAFamiliaException() {
        super("A prisioneira ficou com a familia sem o policial");
    }
}

public class Objetos {
    Filha filhaA;
    Filha filhaB;
    Filho filhoA;
    Filho filhoB;
    Mae mae;
    Pai pai;
    Policial policial;
    Prisioneira prisioneira;
    Margem margemA;
    Margem margemB;
    Jangada jangada;
    public Objetos() {
        this.filhaA = new Filha();
        this.filhaB = new Filha();
        this.filhoA = new Filho();
        this.filhoB = new Filho();
        this.mae = new Mae();
        this.pai = new Pai();
        this.policial = new Policial();
        this.prisioneira = new Prisioneira();
        this.margemA = new Margem();
        this.margemB = new Margem();
        this.jangada = new Jangada();
    }
}

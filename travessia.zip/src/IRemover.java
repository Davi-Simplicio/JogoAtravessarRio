public interface IRemover {
    void remover(Personagem personagem) throws PersonagemNaoExisteException;
}

public class PaiTransportandoFilhasException  extends RuntimeException{
    public PaiTransportandoFilhasException() {
        super("O pai não pode transportar as filhas");
    }
}

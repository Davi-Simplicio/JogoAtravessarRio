public class Policial extends Personagem{
}

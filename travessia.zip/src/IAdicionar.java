public interface IAdicionar {

    Personagem adicionar(Personagem personagem) throws JangadaCheiaException, PersonagemNaoExisteException;
}

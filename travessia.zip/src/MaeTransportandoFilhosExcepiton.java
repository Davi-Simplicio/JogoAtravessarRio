public class MaeTransportandoFilhosExcepiton extends RuntimeException{
    public MaeTransportandoFilhosExcepiton() {
        super("A mãe não pode transportar os filhos");
    }
}

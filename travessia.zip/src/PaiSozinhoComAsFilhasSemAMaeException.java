public class PaiSozinhoComAsFilhasSemAMaeException extends RuntimeException{
    public PaiSozinhoComAsFilhasSemAMaeException() {
        super("As filhas não podem ficar sozinhas com o pai sem a a mãe");
    }
}

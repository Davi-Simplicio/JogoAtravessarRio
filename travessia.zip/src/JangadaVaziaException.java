public class JangadaVaziaException extends Exception{
    public JangadaVaziaException() {
        super("A jangada não pode ir vazia");
    }
}

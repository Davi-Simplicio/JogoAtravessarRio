public abstract class Personagem {
}
